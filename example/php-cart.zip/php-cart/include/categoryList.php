<?php
$productsPerRow = 3;
$productsPerPage = 9;

//$productList    = getProductList($catId);
$children = array_merge(array($catId), getChildCategories(NULL, $catId));
$children = ' (' . implode(', ', $children) . ')';

$sql = "SELECT pd_id, pd_name, pd_price, pd_thumbnail, pd_qty, c.cat_id
		FROM tbl_product pd, tbl_category c
		WHERE pd.cat_id = c.cat_id AND pd.cat_id IN $children
		ORDER BY pd_name";
$result     =  mysqli_query($link, getPagingQuery($sql, $productsPerPage));
$pagingLink = getPagingLink($sql, $productsPerPage, "c=$catId");
$numProduct = mysqli_fetch_array($result);
// the product images are arranged in a table. to make sure
// each image gets equal space set the cell width here
$columnWidth = (int)(100 / $productsPerRow);
?>

<table width="780px" border="0" cellspacing="0" cellpadding="20">
<?php
if ($numProduct > 0 ) {

	$i = 0;
	while ($row = mysqli_fetch_array($result)) {

		extract($row);
		if ($pd_thumbnail) {
			$pd_thumbnail = 'images/product/' . $pd_thumbnail;
		} else {
			$pd_thumbnail = 'images/no-image-small.png';
		}

		if ($i % $productsPerRow == 0) {
			echo '<tr>';
		}

		// format how we display the price
		$pd_price = displayAmount($pd_price);

		// we have $pd_name, $pd_price, $pd_description, $pd_image, $cart_url
		$product = getProductDetail($pd_id, $cat_id);

		extract($product);

        ?>


		<td>
		<div class="prod_box">
        	<div class="top_prod_box"></div>
            <div class="center_prod_box">
                 <div class="product_title"><a class="product_name" href="<?php echo $_SERVER['PHP_SELF']."?c=".$cat_id."&p=".$pd_id; ?>"><?php echo $pd_name; ?></a></div><br />
                 <div class="product_img"><a href="<?php echo $_SERVER['PHP_SELF']."?c=".$cat_id."&p=".$pd_id; ?>">
					 <img src="<?php echo $pd_thumbnail; ?>" border="0" /></a></div>
                
                 <div class="prod_price"> <span class="price">Price: $<?php echo $pd_price; ?></span></div>
                

            
             
                 
            </div>
            <!-- end of center_prod_box -->
            <div class="bottom_prod_box"></div>
            <div class="prod_details_tab">
            <a href="javascript:window.location.href='<?php echo $cart_url; ?>';" title="Add to cart"><img src="addcart.gif" alt="" title="" border="0" class="left_bt" /></a>
            <a href="#">
				<img src="images/favs.gif" alt="Feature item" title="Feature" border="0" class="left_bt" /></a>
            <a href="#">
				<img src="images/favorites.gif" alt="Favorite item" title="Favorite" border="0" class="left_bt" /></a>
            <a href="<?php echo $_SERVER['PHP_SELF']."?c=".$catId."&p=".$pd_id; ?>" title="View details" class="prod_details">&nbsp;&nbsp;&nbsp;View</a>
            </div>
            <!-- end of prod_details_tab -->
        </div>
        <!-- end of prod_box -->

		<?php

		 // if the product is no longer in stock, tell the customer
		if ($pd_qty <= 0) {
			echo " (Out Of Stock)";
		}

		echo "</td>\r\n";

		if ($i % $productsPerRow == $productsPerRow - 1) {
			echo '</tr>';
		}

		$i += 1;
	}

	if ($i % $productsPerRow > 0) {
		echo '<td colspan="' . ($productsPerRow - ($i % $productsPerRow)) . '">&nbsp;</td>';
	}


} else {
?>
	<tr><td width="100%" align="center" valign="center">No products in this category</td></tr>
<?php
}
?>
</table>
<p align="center"><?php echo $pagingLink; ?></p>