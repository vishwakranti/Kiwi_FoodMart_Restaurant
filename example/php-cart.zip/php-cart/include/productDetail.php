<?php

$product = getProductDetail($pdId, $catId);

// we have $pd_name, $pd_price, $pd_description, $pd_image, $cart_url
extract($product);
?>

<table width="100%" border="0" cellspacing="0" cellpadding="10">
 <tr>
  <td valign="top" align="center"></strong><br>
       <strong><?php echo $pd_name; ?><br /><br />
	   <img src="<?php echo $pd_image; ?>" border="0" alt="<?php echo $pd_name; ?>"><br /><br />
	   <input type="button" value="&lt;&lt;Back" onclick="window.history.back()" />
  </td>
  <td valign="top" align="center">

Price: $<?php echo $pd_price; ?><br />
<?php
// if we still have this product in stock
// show the 'Add to cart' button
if ($pd_qty > 0) {
?>

<a href="javascript:window.location.href='<?php echo $cart_url; ?>';">
   <img align="center" src="addcart.gif" border="0">
</a>
<?php
} else {
	echo 'Out Of Stock';
}
?>
  <p><strong><?php echo $pd_description; ?></strong></p>
  </td>
 </tr>
</table>
