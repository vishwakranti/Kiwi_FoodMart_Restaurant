<?php
require_once 'config.php';
require_once 'library/category-functions.php';
require_once 'library/product-functions.php';
require_once 'library/cart-functions.php';
$_SESSION['shop_return_url'] = $_SERVER['REQUEST_URI'];
$catId  = (isset($_GET['c']) && $_GET['c'] != '1') ? $_GET['c'] : 0; // c = category
$pdId   = (isset($_GET['p']) && $_GET['p'] != '') ? $_GET['p'] : 0; // p = products

/*
if ((isset($_GET['c']) && $_GET['c'] != '1'){
	$catId = $_GET['c'];
} else {
	$catId  = 0;
}

if (isset($_GET['p']) && $_GET['p'] != '') {
	$pdId = $_GET['p'];	
} else {
	$pdId = 0;
}
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>VisionTrade NZ Shop</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body bgcolor="#CCCCCC">
<div id="wrapper">
	<div id="wrapper2">
		<div id="header">
			<div id="logo">
				<h1>VisionTrade</h1>
			</div>
			<div id="menu">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="shop.php">Shop</a></li>
					<li><a href="#">Products</a></li>
					<li><a href="#">Services</a></li>
					<li><a href="#">Contact Us</a></li>
				</ul>
			</div>
		</div>
		<!-- end #header -->
		<div id="page">
		           <table width="870" border="0" align="center" cellpadding="0" cellspacing="0">

				   <tr valign="top">
				   <td width="170" height="400" id="leftnav">
				    <?php
				     require_once 'include/leftNav.php';  // display catergories - Left navigation

				    
					?>
				    </td>
				   <td>
				   <p><a href="cart.php?action=view"><img src="cart.gif" border="0" align="right" alt="View Cart"></a></p>
				    <?php
				    if ($pdId) {
				   	require_once 'include/productDetail.php';
				    }
				    else if ($catId) {
				  	require_once 'include/productList.php';
				    } else {
				  	require_once 'include/categoryList.php';
				    }
				    ?>
				    </td>
				   </tr>
				  </table>

			<div style="clear: both;">&nbsp;</div>

		</div>
		<!-- end #page -->
	</div>
	<!-- end #wrapper2 -->
	<div id="footer">
		<p id="legal"><a href="#">Home </a>:<a href="#"> About Us</a>: <a href="#">Products</a>:<a href="#"> Services</a>: <a href="#">Contact Us</a>: VisionTrade by <a href="#">http://Visiontrade.com</a></p>
    <?php
       include "include/footer.php";
    ?>
    </div>
</div>
<!-- end #wrapper -->
</body>
</html>
