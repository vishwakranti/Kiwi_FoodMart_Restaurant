-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2022 at 10:30 PM
-- Server version: 10.1.39-MariaDB
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cart_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `ct_id` int(10) UNSIGNED NOT NULL,
  `pd_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `ct_qty` mediumint(8) UNSIGNED NOT NULL DEFAULT '1',
  `ct_session_id` char(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `ct_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `cat_id` int(10) UNSIGNED NOT NULL,
  `cat_parent_id` int(11) NOT NULL DEFAULT '0',
  `cat_name` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `cat_description` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `cat_image` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`cat_id`, `cat_parent_id`, `cat_name`, `cat_description`, `cat_image`) VALUES
(35, 0, 'Grand Glassware', 'BeiJing WanJinDa Glassware Ltd offering New Zealand’s most comprehensive range of\r\nhospitality glassware from: Arcoroc, Luminarc, Pasabache, Crown, Libbey, Schott.', 'aca1028e1e8e9dc7e062cc03426fa40c.jpg'),
(33, 31, 'White Wine', 'BeiJing WanJinDa Glassware Ltd offering New Zealand’s most comprehensive range of\r\nhospitality glassware from: Arcoroc, Luminarc, Pasabache, Crown, Libbey, Schott.', '7c34932a62e8233e3f6e478e29eed65b.jpg'),
(31, 0, 'Stem Glassware', 'BeiJing WanJinDa Glassware Ltd offering New Zealand’s most comprehensive range of\r\nhospitality glassware from: Arcoroc, Luminarc, Pasabache, Crown, Libbey, Schott.', '6cdf4c60cd0ffe057c1059770d9e8a3b.jpg'),
(32, 31, 'Red Wine', 'BeiJing WanJinDa Glassware Ltd offering New Zealand’s most comprehensive range of\r\nhospitality glassware from: Arcoroc, Luminarc, Pasabache, Crown, Libbey, Schott.', '504d3d66ec068005faea88ee3a099eda.jpg'),
(42, 35, 'candle', 'BeiJing WanJinDa Glassware Ltd offering New Zealand’s most comprehensive range of\r\nhospitality glassware from: Arcoroc, Luminarc, Pasabache, Crown, Libbey, Schott.', 'bc00ebda11aab372f4572d6c7841608d.jpg'),
(41, 35, 'Vase', 'BeiJing WanJinDa Glassware Ltd offering New Zealand’s most comprehensive range of\r\nhospitality glassware from: Arcoroc, Luminarc, Pasabache, Crown, Libbey, Schott.', '8f1424af31efb0b2db3f68e6ca1d6bb3.jpg'),
(40, 31, 'Champaign', 'BeiJing WanJinDa Glassware Ltd offering New Zealand’s most comprehensive range of\r\nhospitality glassware from: Arcoroc, Luminarc, Pasabache, Crown, Libbey, Schott.', '59a9af6d81835c0248eb6cf4d9d47d78.jpg'),
(43, 35, 'Ice cream', 'Ice cream', '54afb29350f69b1856df17f815d9ad89.jpg'),
(44, 0, 'Crystal Glassware', 'BeiJing WanJinDa Glassware Ltd offering New Zealand’s most comprehensive range of\r\nhospitality glassware from: Arcoroc, Luminarc, Pasabache, Crown, Libbey, Schott.', 'b48d39a681e5842692445862f48d8749.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_currency`
--

CREATE TABLE `tbl_currency` (
  `cy_id` int(10) UNSIGNED NOT NULL,
  `cy_code` char(3) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `cy_symbol` varchar(8) COLLATE latin1_general_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `tbl_currency`
--

INSERT INTO `tbl_currency` (`cy_id`, `cy_code`, `cy_symbol`) VALUES
(1, 'EUR', '&#8364;'),
(2, 'GBP', '&pound;'),
(3, 'JPY', '&yen;'),
(4, 'USD', '$');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `od_id` int(10) UNSIGNED NOT NULL,
  `od_date` datetime DEFAULT NULL,
  `od_last_update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `od_status` enum('New','Paid','Shipped','Completed','Cancelled') COLLATE latin1_general_ci NOT NULL DEFAULT 'New',
  `od_memo` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_shipping_first_name` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_shipping_last_name` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_shipping_address1` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_shipping_address2` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_shipping_phone` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_shipping_city` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_shipping_state` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_shipping_postal_code` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_shipping_cost` decimal(5,2) DEFAULT '0.00',
  `od_payment_first_name` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_payment_last_name` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_payment_address1` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_payment_address2` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_payment_phone` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_payment_city` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_payment_state` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `od_payment_postal_code` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`od_id`, `od_date`, `od_last_update`, `od_status`, `od_memo`, `od_shipping_first_name`, `od_shipping_last_name`, `od_shipping_address1`, `od_shipping_address2`, `od_shipping_phone`, `od_shipping_city`, `od_shipping_state`, `od_shipping_postal_code`, `od_shipping_cost`, `od_payment_first_name`, `od_payment_last_name`, `od_payment_address1`, `od_payment_address2`, `od_payment_phone`, `od_payment_city`, `od_payment_state`, `od_payment_postal_code`) VALUES
(10000, '2021-07-26 10:15:32', '2021-07-26 10:15:32', 'New', '', 'Jeffrey', 'Hong', '50 Hazeldean Road', 'Northcote', '0221500440', 'Christchurch', 'Canterbury', '8052', '5.00', 'Jeffrey', 'Hong', '50 Hazeldean Road', 'Northcote', '0221500440', 'Christchurch', 'Canterbury', '8052'),
(10001, '2021-07-26 10:26:15', '2021-07-26 10:26:15', 'New', '', 'Jeffrey', 'Hong', '53 Northcote Road', 'Northcote', '0221500440', 'Christchurch', 'Canterbury', '8052', '5.00', 'Jeffrey', 'Hong', '53 Northcote Road', 'Northcote', '0221500440', 'Christchurch', 'Canterbury', '8052'),
(10002, '2021-07-26 10:30:13', '2021-07-26 10:30:13', 'New', '', 'Jeffrey', 'Hong', '53 Northcote Road', 'Northcote', '0221500440', 'Christchurch', 'Canterbury', '8052', '5.00', 'Jeffrey', 'Hong', '53 Northcote Road', 'Northcote', '0221500440', 'Christchurch', 'Canterbury', '8052'),
(10003, '2021-07-26 10:43:07', '2021-07-26 10:47:49', 'Paid', '', 'Jeffrey', 'Hong', '53 Northcote Road', 'Northcote', '0221500440', 'Christchurch', 'Canterbury', '8052', '5.00', 'Jeffrey', 'Hong', '53 Northcote Road', 'Northcote', '0221500440', 'Christchurch', 'Canterbury', '8052'),
(10004, '2021-08-04 10:02:28', '2021-08-04 10:15:17', 'Completed', '', 'Jeffrey', 'Hong', '50 Hazeldean Road', 'Northcote', '0221500440', 'Christchurch', 'Canterbury', '8052', '5.00', 'Jeffrey', 'Hong', '50 Hazeldean Road', 'Northcote', '0221500440', 'Christchurch', 'Canterbury', '8052');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_item`
--

CREATE TABLE `tbl_order_item` (
  `od_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `pd_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `od_qty` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `tbl_order_item`
--

INSERT INTO `tbl_order_item` (`od_id`, `pd_id`, `od_qty`) VALUES
(10000, 33, 1),
(10000, 79, 1),
(10001, 46, 1),
(10002, 65, 1),
(10003, 65, 1),
(10004, 51, 1),
(10004, 33, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `pd_id` int(10) UNSIGNED NOT NULL,
  `cat_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `pd_name` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `pd_description` text COLLATE latin1_general_ci NOT NULL,
  `pd_price` decimal(9,2) NOT NULL DEFAULT '0.00',
  `pd_qty` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `pd_image` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `pd_thumbnail` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `pd_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pd_last_update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`pd_id`, `cat_id`, `pd_name`, `pd_description`, `pd_price`, `pd_qty`, `pd_image`, `pd_thumbnail`, `pd_date`, `pd_last_update`) VALUES
(33, 32, '1229-21', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '11.00', 86, '08582aec6ce8d8d287f190c3e84e9424.jpg', '16a9d6a592271b875fe7b8c4a9436f21.jpg', '2014-05-20 12:44:24', '0000-00-00 00:00:00'),
(34, 32, '1855-66', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '8.00', 99, 'da76f6ce565606ad3ed62ffb8c568544.jpg', '5c69cd6ddd4b5ec56dab25433870f18f.jpg', '2014-05-20 12:45:16', '0000-00-00 00:00:00'),
(35, 33, '2005-01', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '14.00', 99, '1eb2c49c85641aef7592e181303b3124.jpg', '0832c3c8883af8c27f1f12a37a40d713.jpg', '2014-05-20 12:46:21', '0000-00-00 00:00:00'),
(36, 33, '2005-02', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '8.00', 98, '6e310e9ff7616afc6d98f08fc59234f3.jpg', '57f9120ee955e2d198feecb594390106.jpg', '2014-05-20 12:46:55', '0000-00-00 00:00:00'),
(37, 33, '2005-03', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '10.00', 100, '47f5b187ea8bef7980f5a694b1df8103.jpg', 'c41222ca4426d1bd3318d41d27dfc515.jpg', '2014-05-20 12:47:28', '0000-00-00 00:00:00'),
(39, 33, '2005-04', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '13.00', 99, '505d1a94ecc9dc703857414b4abeff29.jpg', 'fc29134eaf314588e14a017caddd76a5.jpg', '2014-05-21 08:50:56', '0000-00-00 00:00:00'),
(45, 32, '1622-66', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '15.00', 98, 'e808011773937798b184f565b81a7e0d.jpg', '35d90bb3b3b0bf2fe6e5d75b19a182f4.jpg', '2014-05-22 11:04:21', '0000-00-00 00:00:00'),
(46, 32, '1780-47', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '9.00', 97, 'a9687e51eb33ea2d599d84a0778cd52d.jpg', 'dc6c4a635c2c032905b4aa63b682a60b.jpg', '2014-05-22 11:05:02', '0000-00-00 00:00:00'),
(47, 32, '1256-21', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '7.00', 98, '9f91f57eaa0948d6b770613127769dc9.jpg', 'c7f409ade1f948d1fd5e3a69ff6fb4ee.jpg', '2014-05-22 11:05:37', '0000-00-00 00:00:00'),
(48, 32, '1905-1', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '16.00', 100, '83d7eab587f885d9a823af3cb91b03e0.jpg', 'afa3b1fa383cc5f67e83a98ec2eeb9d6.jpg', '2014-05-22 11:06:11', '0000-00-00 00:00:00'),
(49, 33, '2005-05', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '8.00', 98, 'a22f3b60cd09832fdeadfc5c4d05daec.jpg', '2f72a4ad7aa0535c5e4e1b7aae0b263f.jpg', '2014-05-22 11:09:59', '0000-00-00 00:00:00'),
(50, 33, '2005-06', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '11.00', 100, '210a9f42777260b340198aeab7cf3066.jpg', '91e9d6292da9cdfa239c709760f6dd42.jpg', '2014-05-22 11:10:40', '0000-00-00 00:00:00'),
(51, 40, '1799-11', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '8.00', 99, 'd5f02141cef2e575b89530ce688be861.jpg', 'c59c21612f82d1fddc36037535c3485c.jpg', '2014-05-22 11:16:52', '0000-00-00 00:00:00'),
(52, 40, '1799-21', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '8.00', 100, '7056d10a34de1521edb4fd90396bc4ec.jpg', '8dd7baefe1a5332fa1d29ae94e0a4c93.jpg', '2014-05-22 11:18:25', '0000-00-00 00:00:00'),
(53, 40, '1780-2', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '9.00', 97, '246f4f71229225e7c7dea5e91ff45bf1.jpg', '92017752cb1bd04922d0bf61ae2c3db6.jpg', '2014-05-22 11:19:02', '0000-00-00 00:00:00'),
(54, 40, '1891-63', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '11.00', 100, '5778d3bdb1368fcf4994cff19fbb7bb9.jpg', '7ff1ec014020c0aa6c35efea0e91719d.jpg', '2014-05-22 11:20:00', '0000-00-00 00:00:00'),
(55, 40, '1880-10', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '16.00', 100, 'd6fc29c68d2d30d6581916986f0aa3f4.jpg', '8d9e45e14dc9eac515e2e5695379379f.jpg', '2014-05-22 11:20:32', '0000-00-00 00:00:00'),
(56, 40, '1880-9', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '15.00', 99, 'bd3f315875ffa058d51c185405f4d45e.jpg', '48c582dd18c46830643bbfbe65fb4d57.jpg', '2014-05-22 11:21:08', '0000-00-00 00:00:00'),
(61, 42, '198893', '1906-21\r\nItem Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '30.00', 100, 'a80ec04f7f5e448063c22bd0694afa22.jpg', '9a19b16d6307217388cff7e41cf231f8.jpg', '2014-05-22 11:27:24', '0000-00-00 00:00:00'),
(60, 41, '1907-60', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '28.00', 98, '1b347ef29d42821c2d23c878b86fc7fa.jpg', '8d0fd4553602076282ef31b4b0c6ae48.jpg', '2014-05-22 11:26:43', '0000-00-00 00:00:00'),
(59, 41, '1906-21', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '40.00', 98, 'e72896770b7843dfa66c3a81d3ba94ce.jpg', '5e5a3dfbbb2034792c16a336ca827232.jpg', '2014-05-22 11:25:48', '0000-00-00 00:00:00'),
(62, 42, '2035689', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '45.00', 99, 'fa691f0d915cedf01606169edb1bc7e6.jpg', 'fdb90eac1b17b97828771b7e1d035869.jpg', '2014-05-22 11:27:57', '0000-00-00 00:00:00'),
(63, 43, '001', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight: 75g\r\n\r\nVolume: 6mm', '10.00', 98, '3a132c4e2b55bffaa34e3d7b9ceb9b89.jpg', '80903ff4e2843888babdbdcce7a5d626.jpg', '2014-05-28 11:59:30', '0000-00-00 00:00:00'),
(64, 43, '002', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '13.00', 92, '2b82e1f1ab1fd1fc9e01a1883b46caf5.jpg', '23fe8c52c44efc5f504ce5428883c2c4.jpg', '2014-05-28 11:59:47', '0000-00-00 00:00:00'),
(65, 43, '003', 'Item Description : C/53/3079 - \r\nPULP TOTISE 03H09S06Hi NOC\r\n\r\nWeight:\r\n\r\nVolume:', '16.00', 90, 'dd65e0ea1ec1a6b5a38f44ee2027f501.jpg', '451400a8794e6faf6a5604964c0e10db.jpg', '2014-05-28 12:00:05', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shop_config`
--

CREATE TABLE `tbl_shop_config` (
  `sc_name` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `sc_address` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `sc_phone` varchar(30) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `sc_email` varchar(30) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `sc_shipping_cost` decimal(5,2) NOT NULL DEFAULT '0.00',
  `sc_currency` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `sc_order_email` enum('y','n') COLLATE latin1_general_ci NOT NULL DEFAULT 'n'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `tbl_shop_config`
--

INSERT INTO `tbl_shop_config` (`sc_name`, `sc_address`, `sc_phone`, `sc_email`, `sc_shipping_cost`, `sc_currency`, `sc_order_email`) VALUES
('VisionTrade', 'No 334 Manchester Street\r\nChristchurch\r\nNew Zealand', '35198764', 'admin@hotmail.com', '5.00', 4, 'n');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `user_name` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_password` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `user_regdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `user_name`, `user_password`, `user_regdate`, `user_last_login`) VALUES
(6, 'admin', '912ec803b2ce49e4a541068d495ab570', '2018-02-20 17:35:44', '2021-08-04 10:10:36'),
(7, 'mary', '912ec803b2ce49e4a541068d495ab570', '2018-12-10 08:47:06', '2018-12-10 08:47:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`ct_id`),
  ADD KEY `pd_id` (`pd_id`),
  ADD KEY `ct_session_id` (`ct_session_id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`cat_id`),
  ADD KEY `cat_parent_id` (`cat_parent_id`),
  ADD KEY `cat_name` (`cat_name`);

--
-- Indexes for table `tbl_currency`
--
ALTER TABLE `tbl_currency`
  ADD PRIMARY KEY (`cy_id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`od_id`);

--
-- Indexes for table `tbl_order_item`
--
ALTER TABLE `tbl_order_item`
  ADD PRIMARY KEY (`od_id`,`pd_id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`pd_id`),
  ADD KEY `cat_id` (`cat_id`),
  ADD KEY `pd_name` (`pd_name`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `ct_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=298;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `cat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `tbl_currency`
--
ALTER TABLE `tbl_currency`
  MODIFY `cy_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `od_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10005;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `pd_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
