<?php
include 'config.php';

// Set up our error check and result check array
$error = array();
$results = array();

// First check if a form was submitted.
// Since this is a search we will use $_GET

$searchTerms = $_GET['search'];
$searchTerms = $searchTerms; // remove any html tags

if (strlen($searchTerms) < 3) {
     $error[] = "Search terms must be longer than 2 characters.";
}
else {
      $searchTermDB = $searchTerms; // prevent sql injection.
}

// If there are no errors, lets get the search going.
if (count($error) < 1) {
      // grab the search types.
      $types = array();
      $types[] = "pd_name LIKE '%$searchTermDB%'";
      $types[] = "pd_description LIKE '%$searchTermDB%'";

      $query = "SELECT * FROM tbl_product WHERE ";
      $query  .= implode(" || ", $types) . " ORDER BY pd_name";
      $result = mysqli_query($link,$query);

      if (mysqli_num_rows($result) < 1) {
         $error[] = "Your search term yielded no results from our database.";
      }
      else {
         $results = array(); // the result array
         $i = 1;
         while ($row = mysqli_fetch_assoc($result)) {
            $catid= $row['cat_id'];
            $prodid= $row['pd_id'];
            $prodname= $row['pd_name'];
            $proddesc= $row['pd_description'];
			$prodimg= $row['pd_image'];
            $results[] = '<img width="60" src="images/product/'.$prodimg.'">'.'<a href="shop.php?c='.$catid.'&p='.$prodid.'">'.$prodname.'</a> '.$proddesc.'<br/><br/>';
            $i++;
         } // end of while
      } // end of else
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>VisionTrade.com NZ Home </title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
	<div id="wrapper2">
		<div id="header">
			<div id="logo">
				<h1>VisionTrade</h1>
			</div>
			<div id="menu">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="shop.php">Shop</a></li>
					<li><a href="#">Products</a></li>
					<li><a href="#">Services</a></li>
					<li><a href="#">Contact Us</a></li>
					
				</ul>
			</div>
		</div>
		<!-- end #header -->
		<div id="page">
	    <!-- Search box for keyword in database -->
		<span style="float: right">
           <form method="get" action="search_products.php">
			   <input type="text" name="search" />
			   <input type="submit" value="search" />
		   </form>

		</span>

		<table width="870" border="0" align="center" cellpadding="0" cellspacing="0">
						   <tr valign="top">
						   <td width="170" height="400">
						     <div id="block">
							   <div id="block-heading">Today specials</div>
								<div id="block-text">
								  <a href="#"><img src="images/p1.jpg" width="65" height="58" class="img_left" alt="" title="" border="0"/></a>
							        We want this web site to be an alternative to the existing web sites. We want the people from all over the world not only from New Zealand to be part from our forming group.

							    	        	</div>
								<div id="block-text">
									<a href="#"><img src="images/p2.jpg" width="65" height="58" class="img_left" alt="" title="" border="0"/></a>
								     We accept your criticism and we encourage you to do so and tell us what is good and what is not that good. You can count on us to keep this web site up to date.
							  </div>
                            </div>
						    </td>
						   <td>

						    <h2>-- Search results --</h2>
								
<?php echo (count($results) > 0)?"" . implode("", $results):""; ?>
<?php echo (count($error) > 0)?"<span id=\"error\">" . implode("<br />", $error) . "</span><br /><br />":""; ?>
	               

						    </td>
						   </tr>
						  </table>

			<div style="clear: both;">&nbsp;</div>
		<br>


		</div>
		<!-- end #page -->
	</div>
	<!-- end #wrapper2 -->
	<div id="footer">
		<p id="legal"><a href="#">Home </a>:<a href="#">Shop </a>:<a href="#"> About Us</a>: <a href="#">Products</a>:<a href="#"> Services</a>: <a href="#">Contact Us</a>: VisionTrade.com by <a href="#">http://visiontrade.com</a></p>
  <?php
       include "include/footer.php";
    ?>

  </div>
</div>
<!-- end #wrapper -->
</body>
</html>
