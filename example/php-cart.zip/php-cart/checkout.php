<?php
 require_once 'config.php';
 require_once 'library/cart-functions.php';
 require_once 'library/checkout-functions.php';
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Vision Online Shop</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="include/shop.css" rel="stylesheet" type="text/css">

<script src="library/common.js"></script>
<script src="library/checkout.js"></script>
</head>
<body>
<div id="wrapper">
	<div id="wrapper2">
		<div id="header">
			<div id="logo">
				<h1>VisionTrade</h1>

			</div>
			<div id="menu">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="shop.php">Shop</a></li>
					<li><a href="#">Products</a></li>
					<li><a href="#">Services</a></li>
					<li><a href="#">Contact Us</a></li>
				</ul>
			</div>
		</div>
		<!-- end #header -->
		<div id="page">
                  <table width="870" border="0" align="center" cellpadding="0" cellspacing="0">
                   <tr valign="top">

				   <td >
				    <br>
                     <?php
					  if (isset($_GET['step']) && (int)$_GET['step'] > 0 && (int)$_GET['step'] <= 3) {
					 	$step = (int)$_GET['step'];

					 	$includeFile = '';
					 	if ($step == 1) {
					 		$includeFile = 'shippingAndPaymentInfo.php';
					 		$pageTitle   = 'Checkout - Step 1 of 2';
					 	}

					 	else if ($step == 2) {
					 		$includeFile = 'checkoutConfirmation.php';
					 		$pageTitle   = 'Checkout - Step 2 of 2';
					 	}

					 	else if ($step == 3) {
					 		$orderId     = saveOrder();
					 		$orderAmount = getOrderAmount($orderId);

					 		$_SESSION['orderId'] = $orderId;

					 		// our next action depends on the payment method
					 		// if the payment method is COD then show the
					 		// success page but when paypal is selected
					 		// send the order details to paypal
					 		if ($_POST['hidPaymentMethod'] == 'cod') {

					 		   // header('Location: success.php');
					 		 unset($_SESSION['orderId']);

							 ?>
							  <p>&nbsp;</p>
							  <table width="500" border="0" align="center" cellpadding="1" cellspacing="0">
							     <tr>
							        <td align="left" valign="top" bgcolor="#333333"> <table width="100%" border="0" cellspacing="0" cellpadding="0">
							              <tr>
							                 <td align="center" bgcolor="#EEEEEE"> <p>&nbsp;</p>
							                          <p>Thank you for shopping with us! We will send the purchased
							                              item(s) immediately. To continue shopping please <a href="index.php">click
							                              here</a></p>
							                    <p>&nbsp;</p></td>
							              </tr>
							           </table></td>
							     </tr>
							  </table>
							  <br>
                           <?php
					 			exit;
					 		} else {
					 			$includeFile = 'paypal/payment.php';
					 		}
					 	}
					    }
					    else {
					 	// missing or invalid step number, just redirect
					 	header('Location: index.php');
					 }

					 //require_once 'include/header.php';
					 ?>
					 <?php
					   require_once "include/$includeFile";
                      ?>

				    </td>

				   </tr>

				  </table>


			<div style="clear: both;">&nbsp;</div>

		</div>
		<!-- end #page -->
	</div>
	<!-- end #wrapper2 -->
	<div id="footer">
		<p id="legal"><a href="#">Home </a>:<a href="#"> About Us</a>: <a href="#">Products</a>:<a href="#"> Services</a>: <a href="#">Contact Us</a>: Vision Online Shop by <a href="#">http://jeffstuff.freehostia.com</a></p>
  </div>
</div>
<!-- end #wrapper -->
</body>
</html>
