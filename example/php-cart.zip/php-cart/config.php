<?php
// start the session
session_start();

// database connection config
$dbHost = 'localhost';
$dbUser = 'root';
$dbPass = '';
$dbName = 'cart_database';
$link = mysqli_connect ($dbHost, $dbUser, $dbPass,$dbName); 
// set SRV_ROOT for inserting images/photos
define('SRV_ROOT', 'c:/xampp/htdocs/php-cart/');

// these are the directories where we will store all
// category and product images
define('CATEGORY_IMAGE_DIR', 'images/category/');
define('PRODUCT_IMAGE_DIR',  'images/product/');

// some size limitation for the category
// and product images

// all category image width must not exceed 75 pixels
define('MAX_CATEGORY_IMAGE_WIDTH', 85);

// do we need to limit the product image width? Setting this value to 'true' is recommended
define('LIMIT_PRODUCT_WIDTH',     true);

// maximum width for all product image
define('MAX_PRODUCT_IMAGE_WIDTH', 300);

// the width for product thumbnail
define('THUMBNAIL_WIDTH',         75);


// since all page will require a database access and the common library is also used by all
// it's logical to load these library here

//require_once 'database.php';
require_once 'library/common.php';

// get the shop configuration ( name, addres, etc ), all page need it
$shopConfig = getShopConfig();
?>