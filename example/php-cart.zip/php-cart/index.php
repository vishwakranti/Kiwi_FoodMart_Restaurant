<?php
  include "config.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>VisionTrade.com NZ Home </title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
	<div id="wrapper2">
		<div id="header">
			<div id="logo">
				<h1>VisionTrade</h1>
			</div>
			<div id="menu">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="shop.php">Shop</a></li>
					<li><a href="#">Products</a></li>
					<li><a href="#">Services</a></li>
					<li><a href="#">Contact Us</a></li>
					
				</ul>
			</div>
		</div>
		<!-- end #header -->
		<div id="page">
	    <!-- Search box for keyword in database -->
		<span style="float: right">
           <form method="get" action="search_products.php">
			   <input type="text" name="search" />
			   <input type="submit" value="search" />
		   </form>

		</span>

		<table width="870" border="0" align="center" cellpadding="0" cellspacing="0">
						   <tr valign="top">
						   <td width="170" height="400">
						     <div id="block">
							   <div id="block-heading">Today specials</div>
								<div id="block-text">
								  <a href="#"><img src="images/p1.jpg" width="65" height="58" class="img_left" alt="" title="" border="0"/></a>
							        We want this web site to be an alternative to the existing web sites. We want the people from all over the world not only from New Zealand to be part from our forming group.

							    	        	</div>
								<div id="block-text">
									<a href="#"><img src="images/p2.jpg" width="65" height="58" class="img_left" alt="" title="" border="0"/></a>
								     We accept your criticism and we encourage you to do so and tell us what is good and what is not that good. You can count on us to keep this web site up to date.
							  </div>
                            </div>
						    </td>
						   <td>

						    <h2>VisionTrade</h2>
									<p><img src="images/product.jpg" width="160" align="left" class="spacing" />We have been a retailer of New Zealand gifts and jewelry since 2003. We are proud to feature one of the largest ranges of unique gifts from New Zealand.
									</P>
									<p>
									If you have just visited New Zealand or are intending to do so, why burnden yourself with carrying gifts all the way home. We can have all your New Zealand Souvenirs shipped to your door anywhere worldwide.
									</p>
									<p>
									Take some time to browse our store and discover for yourself some unique and wonderful gifts for birthdays. Silverfernz.com features New Zealand Skincare products for girls, Maori Weapons and All Blacks items for guys, Books and Clothes for Children, cool t-shirts for everyone, stunning wooden gifts which are suitable for everybody.
									</p>
									<p>
									Your Mother is a very special person and someone whom deserves a very special gift. We feature a complete range of gifts perfect to make your mother feel like the special person she is. Take a look at our New Zealand Aromatherapy range or our Snowy Peak range of knitwear.
									</P>

						    </td>
						   </tr>
						  </table>

			<div style="clear: both;">&nbsp;</div>
		<br>


		</div>
		<!-- end #page -->
	</div>
	<!-- end #wrapper2 -->
	<div id="footer">
		<p id="legal"><a href="#">Home </a>:<a href="#">Shop </a>:<a href="#"> About Us</a>: <a href="#">Products</a>:<a href="#"> Services</a>: <a href="#">Contact Us</a>: VisionTrade.com by <a href="#">http://visiontrade.com</a></p>
  <?php
       include "include/footer.php";
    ?>

  </div>
</div>
<!-- end #wrapper -->
</body>
</html>
